#if UNITY_EDITOR
//-----------------------------------------------------------------------// <copyright file="DelegateExamples.cs" company="Sirenix IVS"> // Copyright (c) Sirenix IVS. All rights reserved.// </copyright>//-----------------------------------------------------------------------
//namespace Sirenix.OdinInspector.Editor.Examples
//{
//    using UnityEngine;
//    using Sirenix.OdinInspector;
//    using System;

//    public class DelegateExamples : SerializedMonoBehaviour
//    {
//        public Action<Vector3> A;
//        public Func<int> B;
//        public Action C;
//        public Action<int> D;

//        public void TestMethod(int someInt)
//        {
//            Debug.Log(someInt);
//        }
//    }
//}
#endif