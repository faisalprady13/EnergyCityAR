#if UNITY_EDITOR
//-----------------------------------------------------------------------// <copyright file="IncorrectUseOfOdinSerializeAttributeExamples2.cs" company="Sirenix IVS"> // Copyright (c) Sirenix IVS. All rights reserved.// </copyright>//-----------------------------------------------------------------------
//namespace Sirenix.OdinInspector.Editor.Examples
//{
//    using Sirenix.Serialization;

//    [TypeInfoBox(
//        "This example demonstrates how a field in some cases can be serialized by both Odin and Unity at the same time.\n" +
//        "You can verify this for yourself by using the Serialization Debugger.")]
//    public class IncorrectUseOfOdinSerializeAttributeExamples2 : SerializedMonoBehaviour
//    {
//        [OdinSerialize]
//        public MyCustomType UnityAndOdinSerializedField1;

//        [OdinSerialize]
//        public int UnityAndOdinSerializedField2;

//        [System.Serializable]
//        public class MyCustomType
//        {
//            public int Test;
//        }
//    }
//}
#endif