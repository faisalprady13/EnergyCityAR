#if UNITY_EDITOR
//-----------------------------------------------------------------------// <copyright file="RequiredAttributeDrawer.cs" company="Sirenix IVS"> // Copyright (c) Sirenix IVS. All rights reserved.// </copyright>//-----------------------------------------------------------------------
//-----------------------------------------------------------------------
// <copyright file="RequiredAttributeDrawer.cs" company="Sirenix IVS">
// Copyright (c) Sirenix IVS. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace Sirenix.OdinInspector.Editor.Drawers
{
    using UnityEditor;
    using UnityEngine;
    using Sirenix.Utilities.Editor;

    /// <summary>
    /// Draws properties marked with <see cref="RequiredAttribute"/>.
    /// </summary>
    /// <seealso cref="RequiredAttribute"/>
    /// <seealso cref="InfoBoxAttribute"/>
    /// <seealso cref="ValidateInputAttribute"/>

    [DrawerPriority(DrawerPriorityLevel.WrapperPriority)]
    public sealed class RequiredAttributeDrawer : OdinAttributeDrawer<RequiredAttribute>
    {
        /// <summary>
        /// Draws the property.
        /// </summary>
        protected override void DrawPropertyLayout(GUIContent label)
        {
            if (Property.ValueEntry.BaseValueType.IsValueType)
            {
                //SirenixEditorGUI.ErrorMessageBox("Value types cannot be null, and thus cannot be marked as required.");
                return;
            }

            // Message context.
            PropertyContext<StringMemberHelper> context = null;
            if (Attribute.ErrorMessage != null)
            {
                context = Property.Context.Get<StringMemberHelper>(this, "ErrorMessage", (StringMemberHelper)null);
                if (context.Value == null)
                {
                    //context.Value = new StringMemberHelper(property.ParentType, attribute.ErrorMessage);
                    context.Value = new StringMemberHelper(Property, this.Attribute.ErrorMessage);
                }

                if (context.Value.ErrorMessage != null)
                {
                    SirenixEditorGUI.ErrorMessageBox(context.Value.ErrorMessage);
                }
            }

            var isMissing = CheckIsMissing(Property);

            if (isMissing)
            {
                string msg = Attribute.ErrorMessage != null ? context.Value.GetString(Property) : (Property.NiceName + " is required.");
                if (Attribute.MessageType == InfoMessageType.Warning)
                {
                    SirenixEditorGUI.WarningMessageBox(msg);
                }
                else if (Attribute.MessageType == InfoMessageType.Error)
                {
                    SirenixEditorGUI.ErrorMessageBox(msg);
                }
                else
                {
                    EditorGUILayout.HelpBox(msg, (MessageType)Attribute.MessageType);
                }
            }

            var key = UniqueDrawerKey.Create(Property, this);
            SirenixEditorGUI.BeginShakeableGroup(key);
            this.CallNextDrawer(label);
            SirenixEditorGUI.EndShakeableGroup(key);

            if (!isMissing && CheckIsMissing(Property))
            {
                SirenixEditorGUI.StartShakingGroup(key);
            }
        }

        private static bool CheckIsMissing(InspectorProperty property)
        {
            bool isMissing = property.ValueEntry.WeakSmartValue == null;

            if (isMissing == false && property.ValueEntry.WeakSmartValue is UnityEngine.Object)
            {
                var unityObject = property.ValueEntry.WeakSmartValue as UnityEngine.Object;
                if (unityObject == null)
                {
                    isMissing = true;
                }
            }
            else if (isMissing == false && property.ValueEntry.WeakSmartValue is string)
            {
                if (string.IsNullOrEmpty((string)property.ValueEntry.WeakSmartValue))
                {
                    isMissing = true;
                }
            }

            return isMissing;
        }
    }
}
#endif